/**
 * ZAIDI Portfolio — API Client
 * ─────────────────────────────
 * Drop this script into any HTML page:
 *   <script src="api.js"></script>
 *
 * Then use: ZaidiAPI.projects.getAll(), etc.
 *
 * Change API_BASE to your Render URL in production.
 */

const ZaidiAPI = (() => {

  // ── CONFIG ───────────────────────────────────
  const API_BASE = window.ZAIDI_API_URL
    || (location.hostname === 'localhost'
        ? 'http://localhost:5000/api'
        : 'https://zaidi-api.onrender.com/api');   // ← replace with your Render URL

  const TOKEN_KEY = 'zaidi_admin_token';

  // ── HELPERS ──────────────────────────────────
  function getToken() {
    return sessionStorage.getItem(TOKEN_KEY);
  }

  function setToken(token) {
    sessionStorage.setItem(TOKEN_KEY, token);
  }

  function clearToken() {
    sessionStorage.removeItem(TOKEN_KEY);
  }

  function authHeaders() {
    const token = getToken();
    return token ? { 'Authorization': `Bearer ${token}` } : {};
  }

  async function request(method, path, body = null, isProtected = false) {
    const headers = {
      'Content-Type': 'application/json',
      ...(isProtected ? authHeaders() : {}),
    };

    const config = { method, headers };
    if (body) config.body = JSON.stringify(body);

    try {
      const res  = await fetch(`${API_BASE}${path}`, config);
      const data = await res.json();

      if (!res.ok) {
        // Token expired → auto logout
        if (res.status === 401) {
          clearToken();
          ZaidiAPI.events.emit('auth:expired');
        }
        throw new Error(data.error || `HTTP ${res.status}`);
      }

      return data;
    } catch (err) {
      if (err.message.includes('Failed to fetch')) {
        throw new Error('Cannot connect to API. Check your internet or server.');
      }
      throw err;
    }
  }

  // ── CRUD FACTORY ─────────────────────────────
  function resource(path) {
    return {
      getAll : (params = {}) => {
        const qs = new URLSearchParams(params).toString();
        return request('GET', `${path}${qs ? '?' + qs : ''}`);
      },
      getOne : (id)   => request('GET',    `${path}/${id}`),
      create : (body) => request('POST',   path, body, true),
      update : (id, body) => request('PUT', `${path}/${id}`, body, true),
      remove : (id)   => request('DELETE', `${path}/${id}`, null, true),
    };
  }

  // ── EVENT BUS (lightweight) ───────────────────
  const events = {
    _handlers: {},
    on(event, fn)   { (this._handlers[event] ??= []).push(fn); },
    emit(event, data) { (this._handlers[event] || []).forEach(fn => fn(data)); },
  };

  // ── AUTH ─────────────────────────────────────
  const auth = {
    async login(username, password) {
      const data = await request('POST', '/auth/login', { username, password });
      setToken(data.token);
      events.emit('auth:login', data);
      return data;
    },
    logout() {
      clearToken();
      events.emit('auth:logout');
    },
    async verify() {
      try {
        return await request('GET', '/auth/verify', null, true);
      } catch {
        return { valid: false };
      }
    },
    async changePassword(currentPassword, newPassword) {
      return request('POST', '/auth/change-password', { currentPassword, newPassword }, true);
    },
    isLoggedIn: () => !!getToken(),
    getToken,
    setToken,
  };

  // ── ABOUT (singleton) ────────────────────────
  const about = {
    get  : ()     => request('GET', '/about'),
    save : (body) => request('PUT', '/about', body, true),
  };

  // ── HEALTH ───────────────────────────────────
  const health = () => request('GET', '/health');

  // ── PUBLIC API ───────────────────────────────
  return {
    auth,
    about,
    health,
    events,
    projects : resource('/projects'),
    skills   : resource('/skills'),
    ctf      : resource('/ctf'),
    certs    : resource('/certs'),
    blog     : resource('/blog'),
    _base    : API_BASE,
  };

})();

// Make available globally
window.ZaidiAPI = ZaidiAPI;
