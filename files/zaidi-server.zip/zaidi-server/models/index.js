const mongoose = require('mongoose');

// ── PROJECT ──────────────────────────────────
const ProjectSchema = new mongoose.Schema({
  name   : { type: String, required: true, trim: true },
  desc   : { type: String, required: true },
  tech   : { type: String, default: '' },        // comma-separated
  url    : { type: String, default: '' },
  github : { type: String, default: '' },
  image  : { type: String, default: '' },
  status : {
    type    : String,
    enum    : ['active', 'wip', 'done', 'archived'],
    default : 'wip',
  },
  featured : { type: Boolean, default: false },
  order    : { type: Number, default: 0 },
}, { timestamps: true });

// ── SKILL ────────────────────────────────────
const SkillSchema = new mongoose.Schema({
  name     : { type: String, required: true, trim: true },
  category : {
    type : String,
    enum : ['Frontend', 'Backend', 'Security', 'Tools', 'Other'],
    default : 'Other',
  },
  level : { type: Number, min: 0, max: 100, default: 50 },
  icon  : { type: String, default: '' },
  order : { type: Number, default: 0 },
}, { timestamps: true });

// ── CTF WRITEUP ──────────────────────────────
const CTFSchema = new mongoose.Schema({
  name       : { type: String, required: true, trim: true },
  platform   : {
    type    : String,
    enum    : ['HTB', 'THM', 'CTFtime', 'Other'],
    default : 'HTB',
  },
  os         : { type: String, enum: ['Linux', 'Windows', 'Other'], default: 'Linux' },
  difficulty : {
    type    : String,
    enum    : ['easy', 'medium', 'hard', 'insane'],
    default : 'easy',
  },
  tags       : { type: String, default: '' },     // comma-separated
  writeup    : { type: String, default: '' },     // markdown body
  date       : { type: Date, default: Date.now },
  points     : { type: Number, default: 0 },
}, { timestamps: true });

// ── CERTIFICATION ────────────────────────────
const CertSchema = new mongoose.Schema({
  name     : { type: String, required: true, trim: true },
  org      : { type: String, required: true },
  progress : { type: Number, min: 0, max: 100, default: 0 },
  status   : {
    type    : String,
    enum    : ['planned', 'inprogress', 'done'],
    default : 'planned',
  },
  credentialUrl : { type: String, default: '' },
  date          : { type: Date },
}, { timestamps: true });

// ── BLOG POST ────────────────────────────────
const BlogSchema = new mongoose.Schema({
  title    : { type: String, required: true, trim: true },
  slug     : { type: String, unique: true, sparse: true },
  category : {
    type    : String,
    enum    : ['HTB Writeup', 'Dev', 'OSINT', 'Security', 'Personal'],
    default : 'Dev',
  },
  excerpt  : { type: String, default: '' },
  body     : { type: String, default: '' },       // markdown
  tags     : [{ type: String }],
  status   : {
    type    : String,
    enum    : ['draft', 'published'],
    default : 'draft',
  },
  date     : { type: Date, default: Date.now },
  readTime : { type: Number, default: 5 },        // minutes
}, { timestamps: true });

// Auto-generate slug from title
BlogSchema.pre('save', function(next) {
  if (this.isModified('title') && !this.slug) {
    this.slug = this.title
      .toLowerCase()
      .replace(/[^a-z0-9\s-]/g, '')
      .replace(/\s+/g, '-')
      .substring(0, 80);
  }
  next();
});

// ── ABOUT / PROFILE ──────────────────────────
const AboutSchema = new mongoose.Schema({
  name       : { type: String, default: '' },
  nickname   : { type: String, default: '' },
  title      : { type: String, default: '' },
  bio        : { type: String, default: '' },
  location   : { type: String, default: '' },
  university : { type: String, default: '' },
  email      : { type: String, default: '' },
  github     : { type: String, default: '' },
  linkedin   : { type: String, default: '' },
  htb        : { type: String, default: '' },
  twitter    : { type: String, default: '' },
  cvUrl      : { type: String, default: '' },
  avatar     : { type: String, default: '' },
}, { timestamps: true });

module.exports = {
  Project : mongoose.model('Project', ProjectSchema),
  Skill   : mongoose.model('Skill',   SkillSchema),
  CTF     : mongoose.model('CTF',     CTFSchema),
  Cert    : mongoose.model('Cert',    CertSchema),
  Blog    : mongoose.model('Blog',    BlogSchema),
  About   : mongoose.model('About',   AboutSchema),
};
