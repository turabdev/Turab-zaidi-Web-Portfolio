const mongoose = require('mongoose');
const bcrypt   = require('bcryptjs');

const AdminSchema = new mongoose.Schema({
  username : { type: String, required: true, unique: true, trim: true },
  password : { type: String, required: true, minlength: 8 },
}, { timestamps: true });

// Hash password before save
AdminSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  const salt = await bcrypt.genSalt(12);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

// Compare password helper
AdminSchema.methods.matchPassword = async function(plain) {
  return bcrypt.compare(plain, this.password);
};

// Never send password in JSON
AdminSchema.methods.toJSON = function() {
  const obj = this.toObject();
  delete obj.password;
  return obj;
};

module.exports = mongoose.model('Admin', AdminSchema);
