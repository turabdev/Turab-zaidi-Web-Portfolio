const mongoose = require('mongoose');

const BlogSchema = new mongoose.Schema({
  title:   { type: String, required: true, trim: true },
  slug:    { type: String, unique: true },
  category:{ type: String, required: true },
  excerpt: { type: String, default: '' },
  content: { type: String, default: '' },
  tags:    { type: String, default: '' },
  date:    { type: String, required: true },
  status:  { type: String, enum: ['draft','published'], default: 'draft' },
  readTime:{ type: Number, default: 5 },
}, { timestamps: true });

// Auto-generate slug
BlogSchema.pre('save', function(next) {
  if (!this.slug) {
    this.slug = this.title.toLowerCase()
      .replace(/[^a-z0-9\s-]/g,'').replace(/\s+/g,'-').substring(0,80);
  }
  next();
});

module.exports = mongoose.model('Blog', BlogSchema);
