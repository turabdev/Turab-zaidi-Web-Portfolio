const mongoose = require('mongoose');

const SkillSchema = new mongoose.Schema({
  name:    { type: String, required: true, trim: true },
  category:{ type: String, required: true, enum: ['Frontend','Backend','Security','Tools','Other'] },
  level:   { type: Number, required: true, min: 0, max: 100 },
  icon:    { type: String, default: '' },
  order:   { type: Number, default: 0 },
}, { timestamps: true });

module.exports = mongoose.model('Skill', SkillSchema);
