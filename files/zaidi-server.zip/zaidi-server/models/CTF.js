const mongoose = require('mongoose');

const CTFSchema = new mongoose.Schema({
  name:      { type: String, required: true, trim: true },
  platform:  { type: String, required: true, enum: ['HTB','THM','CTFtime','Other'] },
  os:        { type: String, required: true, enum: ['Linux','Windows','Other'] },
  difficulty:{ type: String, required: true, enum: ['easy','medium','hard','insane'] },
  tags:      { type: String, default: '' },
  writeup:   { type: String, default: '' },
  date:      { type: String, required: true },
  rooted:    { type: Boolean, default: true },
}, { timestamps: true });

module.exports = mongoose.model('CTF', CTFSchema);
