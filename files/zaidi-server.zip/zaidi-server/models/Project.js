const mongoose = require('mongoose');

const ProjectSchema = new mongoose.Schema({
  name:    { type: String, required: true, trim: true },
  desc:    { type: String, required: true },
  tech:    { type: String, required: true },
  url:     { type: String, default: '' },
  github:  { type: String, default: '' },
  image:   { type: String, default: '' },
  status:  { type: String, enum: ['active','wip','done','archived'], default: 'wip' },
  featured:{ type: Boolean, default: false },
  order:   { type: Number, default: 0 },
}, { timestamps: true });

module.exports = mongoose.model('Project', ProjectSchema);
