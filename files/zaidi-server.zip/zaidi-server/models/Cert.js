const mongoose = require('mongoose');

const CertSchema = new mongoose.Schema({
  name:    { type: String, required: true, trim: true },
  org:     { type: String, required: true },
  progress:{ type: Number, min: 0, max: 100, default: 0 },
  status:  { type: String, enum: ['inprogress','done','planned'], default: 'planned' },
  issueDate:{ type: String, default: '' },
  credUrl: { type: String, default: '' },
}, { timestamps: true });

module.exports = mongoose.model('Cert', CertSchema);
