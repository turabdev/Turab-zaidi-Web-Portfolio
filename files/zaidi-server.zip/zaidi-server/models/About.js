const mongoose = require('mongoose');

// Singleton — only one document
const AboutSchema = new mongoose.Schema({
  name:      { type: String, default: 'Syed Turab Haider Zaidi' },
  nickname:  { type: String, default: 'Zaidi Sama' },
  title:     { type: String, default: 'Full Stack Developer & Pentester' },
  location:  { type: String, default: 'Lahore, Pakistan' },
  university:{ type: String, default: 'Superior University' },
  bio:       { type: String, default: '' },
  github:    { type: String, default: '' },
  linkedin:  { type: String, default: '' },
  email:     { type: String, default: '' },
  htb:       { type: String, default: '' },
  twitter:   { type: String, default: '' },
  cvUrl:     { type: String, default: '' },
}, { timestamps: true });

module.exports = mongoose.model('About', AboutSchema);
