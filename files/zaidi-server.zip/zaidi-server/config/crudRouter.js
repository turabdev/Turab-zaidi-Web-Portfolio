/**
 * crudRouter(Model, options)
 *
 * Generates a full CRUD Express router for a Mongoose model.
 * Public GET routes — protected POST / PUT / DELETE.
 *
 * Options:
 *   sortField  : string  — field to sort by (default: 'createdAt')
 *   sortOrder  : number  — 1 (asc) or -1 (desc) (default: -1)
 *   searchFields: []     — fields to search with ?search=query
 *   publicFields: {}     — project fields for public GET (hides sensitive data)
 */

const router  = require('express').Router;
const protect = require('../middleware/auth');

module.exports = function crudRouter(Model, options = {}) {
  const {
    sortField    = 'createdAt',
    sortOrder    = -1,
    searchFields = [],
    publicFields = {},
  } = options;

  const r = router();

  // ── GET all (public) ─────────────────────────
  r.get('/', async (req, res) => {
    try {
      const { search, limit = 50, page = 1 } = req.query;
      const query = {};

      // Full-text search across searchFields
      if (search && searchFields.length) {
        query.$or = searchFields.map(f => ({
          [f]: { $regex: search, $options: 'i' },
        }));
      }

      const skip  = (parseInt(page) - 1) * parseInt(limit);
      const total = await Model.countDocuments(query);
      const items = await Model.find(query, publicFields)
        .sort({ [sortField]: sortOrder })
        .skip(skip)
        .limit(parseInt(limit));

      res.json({
        data  : items,
        total,
        page  : parseInt(page),
        pages : Math.ceil(total / parseInt(limit)),
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // ── GET single (public) ──────────────────────
  r.get('/:id', async (req, res) => {
    try {
      const item = await Model.findById(req.params.id, publicFields);
      if (!item) return res.status(404).json({ error: 'Not found.' });
      res.json(item);
    } catch (err) {
      if (err.kind === 'ObjectId') return res.status(404).json({ error: 'Invalid ID.' });
      res.status(500).json({ error: err.message });
    }
  });

  // ── POST create (protected) ──────────────────
  r.post('/', protect, async (req, res) => {
    try {
      const item = await Model.create(req.body);
      res.status(201).json(item);
    } catch (err) {
      if (err.code === 11000) {
        return res.status(400).json({ error: 'Duplicate entry. A record with this value already exists.' });
      }
      if (err.name === 'ValidationError') {
        const messages = Object.values(err.errors).map(e => e.message);
        return res.status(400).json({ error: messages.join(', ') });
      }
      res.status(500).json({ error: err.message });
    }
  });

  // ── PUT update (protected) ───────────────────
  r.put('/:id', protect, async (req, res) => {
    try {
      const item = await Model.findByIdAndUpdate(
        req.params.id,
        { $set: req.body },
        { new: true, runValidators: true }
      );
      if (!item) return res.status(404).json({ error: 'Not found.' });
      res.json(item);
    } catch (err) {
      if (err.name === 'ValidationError') {
        const messages = Object.values(err.errors).map(e => e.message);
        return res.status(400).json({ error: messages.join(', ') });
      }
      res.status(500).json({ error: err.message });
    }
  });

  // ── DELETE (protected) ───────────────────────
  r.delete('/:id', protect, async (req, res) => {
    try {
      const item = await Model.findByIdAndDelete(req.params.id);
      if (!item) return res.status(404).json({ error: 'Not found.' });
      res.json({ message: '✅ Deleted successfully.', id: req.params.id });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  return r;
};
