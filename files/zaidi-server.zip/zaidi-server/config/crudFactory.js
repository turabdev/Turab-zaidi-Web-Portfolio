// Generic CRUD route factory
// Usage: router.use('/', crudFactory(Model, publicFields))
const crudFactory = (Model, publicFields = null) => {
  const router = require('express').Router();
  const { protect } = require('../middleware/auth');

  // GET all — PUBLIC
  router.get('/', async (req, res) => {
    try {
      const docs = await Model.find().sort({ order: 1, createdAt: -1 });
      res.json(docs);
    } catch (err) { res.status(500).json({ error: err.message }); }
  });

  // GET one — PUBLIC
  router.get('/:id', async (req, res) => {
    try {
      const doc = await Model.findById(req.params.id);
      if (!doc) return res.status(404).json({ error: 'Not found.' });
      res.json(doc);
    } catch (err) { res.status(500).json({ error: err.message }); }
  });

  // POST create — PROTECTED
  router.post('/', protect, async (req, res) => {
    try {
      const doc = await Model.create(req.body);
      res.status(201).json(doc);
    } catch (err) { res.status(400).json({ error: err.message }); }
  });

  // PUT update — PROTECTED
  router.put('/:id', protect, async (req, res) => {
    try {
      const doc = await Model.findByIdAndUpdate(req.params.id, req.body, {
        new: true, runValidators: true,
      });
      if (!doc) return res.status(404).json({ error: 'Not found.' });
      res.json(doc);
    } catch (err) { res.status(400).json({ error: err.message }); }
  });

  // DELETE — PROTECTED
  router.delete('/:id', protect, async (req, res) => {
    try {
      const doc = await Model.findByIdAndDelete(req.params.id);
      if (!doc) return res.status(404).json({ error: 'Not found.' });
      res.json({ message: 'Deleted successfully.', id: req.params.id });
    } catch (err) { res.status(500).json({ error: err.message }); }
  });

  return router;
};

module.exports = crudFactory;
