// Run once to seed your MongoDB with default data
// Usage: node config/seed.js
require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt   = require('bcryptjs');

const User    = require('../models/User');
const Project = require('../models/Project');
const Skill   = require('../models/Skill');
const CTF     = require('../models/CTF');
const Cert    = require('../models/Cert');
const Blog    = require('../models/Blog');
const About   = require('../models/About');

async function seed() {
  await mongoose.connect(process.env.MONGO_URI);
  console.log('Connected to MongoDB');

  // Clear existing
  await Promise.all([
    User.deleteMany(), Project.deleteMany(), Skill.deleteMany(),
    CTF.deleteMany(), Cert.deleteMany(), Blog.deleteMany(), About.deleteMany()
  ]);

  // Admin user
  await User.create({ username: 'admin', password: 'zaidi2025' });
  console.log('Admin user created: admin / zaidi2025');

  // About
  await About.create({
    name: 'Syed Turab Haider Zaidi', nickname: 'Zaidi Sama',
    title: 'Full Stack Developer & Pentester',
    location: 'Lahore, Pakistan', university: 'Superior University',
    bio: 'CS final semester student at Superior University. Self-taught developer and cybersecurity enthusiast with background in pre-medicine.',
    github: 'github.com/zaidi-sama', email: 'zaidi.sama@email.com',
    htb: 'app.hackthebox.com/profile/zaidi',
  });

  // Projects
  await Project.insertMany([
    { name:'Bahifazat', desc:'School transport safety PWA for Lahore', tech:'Next.js, NestJS, Socket.io, PostgreSQL', status:'active', featured:true, order:1 },
    { name:'AI Payload Analyzer', desc:'AI-powered malware payload analysis', tech:'React, Python, TensorFlow', status:'wip', featured:true, order:2 },
    { name:'OSINT Dashboard', desc:'Passive recon dashboard for journalist', tech:'Node.js, MongoDB, spiderfoot', status:'done', order:3 },
    { name:'This Portfolio', desc:'OS-simulation portfolio with dual desktops', tech:'React, Express, MongoDB', status:'active', featured:true, order:4 },
  ]);

  // Skills
  await Skill.insertMany([
    { name:'React / Next.js', category:'Frontend', level:88, order:1 },
    { name:'HTML & CSS', category:'Frontend', level:95, order:2 },
    { name:'JavaScript', category:'Frontend', level:85, order:3 },
    { name:'Node.js / Express', category:'Backend', level:82, order:4 },
    { name:'MongoDB / Mongoose', category:'Backend', level:78, order:5 },
    { name:'Metasploit', category:'Security', level:75, order:6 },
    { name:'Nmap', category:'Security', level:80, order:7 },
    { name:'OSINT / spiderfoot', category:'Security', level:85, order:8 },
  ]);

  // CTF
  await CTF.insertMany([
    { name:'Nibbles', platform:'HTB', os:'Linux', difficulty:'easy', tags:'File Upload, PHP Webshell, Sudo', date:'2025-03-15' },
    { name:'Jerry', platform:'HTB', os:'Windows', difficulty:'easy', tags:'Tomcat, WAR Upload, Msfvenom', date:'2025-02-20' },
    { name:'Blue', platform:'HTB', os:'Windows', difficulty:'easy', tags:'EternalBlue, SMB, MS17-010', date:'2025-02-10' },
    { name:'Lame', platform:'HTB', os:'Linux', difficulty:'medium', tags:'Samba, CVE-2007-2447', date:'2025-01-28' },
  ]);

  // Certs
  await Cert.insertMany([
    { name:'CPTS', org:'Hack The Box Academy', progress:25, status:'inprogress' },
    { name:'HTB Starting Point', org:'Hack The Box', progress:100, status:'done' },
    { name:'Getting Started Module', org:'HTB Academy', progress:100, status:'done' },
  ]);

  // Blog
  await Blog.insertMany([
    { title:'Nibbles — Nibbleblog File Upload RCE', category:'HTB Writeup', date:'2025-03-15', status:'published', readTime:8 },
    { title:'Building a Real-Time GPS Tracking PWA', category:'Dev', date:'2025-02-20', status:'published', readTime:12 },
    { title:'Passive Recon for Journalists', category:'OSINT', date:'2025-01-15', status:'draft', readTime:6 },
  ]);

  console.log('Seed complete!');
  process.exit(0);
}

seed().catch(err => { console.error(err); process.exit(1); });
