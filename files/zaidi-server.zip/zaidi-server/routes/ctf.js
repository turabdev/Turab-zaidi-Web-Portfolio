const router  = require('express').Router();
const CTF     = require('../models/CTF');
const factory = require('../config/crudFactory');
const { protect } = require('../middleware/auth');

router.use('/', factory(CTF));

// Filter by platform
router.get('/platform/:name', async (req, res) => {
  try {
    const docs = await CTF.find({ platform: req.params.name }).sort({ date: -1 });
    res.json(docs);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// Stats summary
router.get('/stats/summary', async (req, res) => {
  try {
    const total   = await CTF.countDocuments();
    const easy    = await CTF.countDocuments({ difficulty: 'easy' });
    const medium  = await CTF.countDocuments({ difficulty: 'medium' });
    const hard    = await CTF.countDocuments({ difficulty: 'hard' });
    const insane  = await CTF.countDocuments({ difficulty: 'insane' });
    const htb     = await CTF.countDocuments({ platform: 'HTB' });
    const thm     = await CTF.countDocuments({ platform: 'THM' });
    res.json({ total, easy, medium, hard, insane, htb, thm });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
