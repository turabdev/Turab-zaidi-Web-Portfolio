const router  = require('express').Router();
const Project = require('../models/Project');
const factory = require('../config/crudFactory');
const { protect } = require('../middleware/auth');

// Standard CRUD
router.use('/', factory(Project));

// Extra: GET featured projects only
router.get('/featured/list', async (req, res) => {
  try {
    const docs = await Project.find({ featured: true }).sort({ order: 1 });
    res.json(docs);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
