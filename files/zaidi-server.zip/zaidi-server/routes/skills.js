const Skill   = require('../models/Skill');
const factory = require('../config/crudFactory');
module.exports = factory(Skill);
