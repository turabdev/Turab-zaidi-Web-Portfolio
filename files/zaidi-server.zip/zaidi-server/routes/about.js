const router = require('express').Router();
const About  = require('../models/About');
const { protect } = require('../middleware/auth');

// GET about — PUBLIC (singleton)
router.get('/', async (req, res) => {
  try {
    let doc = await About.findOne();
    if (!doc) doc = await About.create({});
    res.json(doc);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// PUT update about — PROTECTED
router.put('/', protect, async (req, res) => {
  try {
    let doc = await About.findOne();
    if (!doc) {
      doc = await About.create(req.body);
    } else {
      Object.assign(doc, req.body);
      await doc.save();
    }
    res.json(doc);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

module.exports = router;
