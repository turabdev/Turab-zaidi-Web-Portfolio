const router  = require('express').Router();
const Blog    = require('../models/Blog');
const factory = require('../config/crudFactory');
const { protect } = require('../middleware/auth');

router.use('/', factory(Blog));

// GET by slug — public
router.get('/slug/:slug', async (req, res) => {
  try {
    const doc = await Blog.findOne({ slug: req.params.slug, status: 'published' });
    if (!doc) return res.status(404).json({ error: 'Post not found.' });
    res.json(doc);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET published only — public
router.get('/published/list', async (req, res) => {
  try {
    const docs = await Blog.find({ status: 'published' }).sort({ date: -1 });
    res.json(docs);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
