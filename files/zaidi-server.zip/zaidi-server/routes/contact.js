const router = require('express').Router();
const About  = require('../models/About');
const { protect } = require('../middleware/auth');

// GET contact info — PUBLIC
router.get('/', async (req, res) => {
  try {
    const doc = await About.findOne().select('email github linkedin htb twitter location');
    res.json(doc || {});
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// PUT update contact info — PROTECTED
router.put('/', protect, async (req, res) => {
  try {
    const allowed = ['email','github','linkedin','htb','twitter','location'];
    const update  = {};
    allowed.forEach(k => { if (req.body[k] !== undefined) update[k] = req.body[k]; });

    let doc = await About.findOne();
    if (!doc) doc = await About.create(update);
    else { Object.assign(doc, update); await doc.save(); }
    res.json(doc);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

// POST contact form submission — PUBLIC
router.post('/message', async (req, res) => {
  try {
    const { name, email, message } = req.body;
    if (!name || !email || !message)
      return res.status(400).json({ error: 'Name, email and message are required.' });
    // TODO: wire to nodemailer / Resend / SendGrid
    console.log(`📬 Contact form: [${name} <${email}>]: ${message}`);
    res.json({ message: 'Message received. Thank you!' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
