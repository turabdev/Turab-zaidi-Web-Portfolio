const Cert    = require('../models/Cert');
const factory = require('../config/crudFactory');
module.exports = factory(Cert);
